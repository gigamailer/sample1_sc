    val name = "Vitthal"
    val greeting = "Hello"

    s"$greeting $name, I hope you are having a great day!"
    s"${greeting*2} $name, I hope you are having a great day!"

    val PI = 3.14159
    f"PI evaluates to $PI%.2f"
