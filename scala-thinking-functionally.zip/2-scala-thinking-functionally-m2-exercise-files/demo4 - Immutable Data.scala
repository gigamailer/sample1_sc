val PI = 3.14159
PI = 3.14

var radius = 10
radius = 12
radius = 10.0
