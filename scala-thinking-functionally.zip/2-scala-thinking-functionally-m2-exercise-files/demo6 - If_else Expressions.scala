  val numer:Double = 22
  val denom:Double = 7

  val PI = if (denom != 0)  {numer/denom} else {None}

  val denom:Double = 0
  val PI = if (denom != 0)  {numer/denom}
