object LittleExample {
def main(args:Array[String]) {
  println("Helloo world!");
 }
}