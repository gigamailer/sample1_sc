val daysOfWeekList = List("Mon","Tue","Wed","Thu","Fri","Sat","Sun")

var x = 0; 
while(x < daysOfWeekList.size) {
  println(daysOfWeekList(x))
  x+=1
}
