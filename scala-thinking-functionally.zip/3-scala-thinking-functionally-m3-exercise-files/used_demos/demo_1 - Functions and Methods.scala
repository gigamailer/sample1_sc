val getArea = (radius:Double) => 
{ 
  val PI = 3.14;
  PI * radius * radius
}:Double

def getArea2 (radius:Double):Double =
{
  val PI = 3.14;
  PI * radius * radius
}

getArea(10)
getArea2(10)
