val dayOfWeek = "Monday"

val typeOfDay = dayOfWeek match{
  case "Monday" => "Manic Monday"
  case "Sunday" => "Sleepy Sunday"
}
